import React, { Component } from "react";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.min.js";
import Page1 from "./Components/Page1";
import {
  products as P,
  phones as ph,
  shoes as S,
  watches as W,
  clothes as C,
} from "./array";

export default class App extends Component {
  render() {
    return (
      <>
        <h1 className="text-primary bg-dark p-2 text-center">
          Your Shopping Cart
        </h1>

        <div className="container">
          <div className="btn-group mb-3">
            <button className="btn btn-dark">All</button>

            <button className="btn btn-primary">Phones</button>

            <button className="btn btn-success">Shoes</button>

            <button className="btn btn-warning">Watches</button>
          </div>

          <div className="d-flex flex-wrap">
            {P.map((val, index) => {
              return (
                <Page1
                  key={index}
                  name={val.name}
                  price={val.price}
                  category={val.category}
                  img={val.img}
                />
              );
            })}
          </div>
        </div>
      </>
    );
  }
}
